// Empty placeholder to prevent 404 error
console.log('Cache management handled by service worker');
